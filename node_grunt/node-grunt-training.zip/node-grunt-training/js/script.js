function assignName() {
	var myName = "Omkar";
	return myName;
}
