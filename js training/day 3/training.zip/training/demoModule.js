function demoFuntion(){
  console.log("demo module");
  demoFuntion1();
}

function demoFuntion1(){
  console.log("demo module 223")
}

module.exports = { demoFuntion};
