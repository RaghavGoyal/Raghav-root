const Rectangle = {};

Rectangle.calculateArea = (length, width) =>{
 const area = length * width;
 return area;
};



module.exports = Rectangle;
